from distutils.core import setup

setup(console=['M_gen.py'])